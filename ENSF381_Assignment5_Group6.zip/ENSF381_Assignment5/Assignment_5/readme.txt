List Of The Imports We Used:

We used 2 import that requires command line installation:

Command Used: npm install react-router-dom 

Command Used: npm install

We also used these other imports to ensure connection between all the files related to the React "my-ecommerce-app"

1. import React from 'react';
2. import React, { useEffect, useState } from 'react';
3. import reviews from '../data/reviews';
4. import Header from './Header';
5. import HomeMainSection from './HomeMainSection';
6. import Footer from './Footer';
7. import './App.css';
8. import Homepage from './components/Homepage';
9. import { BrowserRouter as Router } from 'react-router-dom';
10.import ProductItem from './ProductItem';
11.import productsData from '../data/products';
12.import CartItem from './CartItem';
13.import ProductList from './ProductList';
14.import Cart from './Cart';
