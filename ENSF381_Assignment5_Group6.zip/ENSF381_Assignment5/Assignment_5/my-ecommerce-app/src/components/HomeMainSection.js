import React, { useEffect, useState } from 'react';
import reviews from '../data/reviews';

const HomeMainSection = () => {
    const [randomReviews, setRandomReviews] = useState([]);

    useEffect(() => {
        const getRandomReviews = () => {
            const shuffledReviews = [...reviews].sort(() => 0.5 - Math.random());
            const selectedReviews = shuffledReviews.slice(0, 2);
            return selectedReviews;
        };

        setRandomReviews(getRandomReviews());
    }, []);

    return (
        <div style={{ textAlign: 'left', marginLeft: '10px' }}>
            <h2>About Us</h2>
            {/* Company's mission and vision content */}
            <p> 1. Expert Product Knowledge: Our team at CAM30 boasts extensive expertise in the intricate details of cameras and accessories. From sensor technologies to lens specifications, we are well-versed in the technical nuances that make each product unique.</p>
            <p> 2. Technical Support Prowess: Providing exceptional technical support is at the core of our values. Whether you're troubleshooting an issue or seeking advice on optimizing your gear, our team is dedicated to ensuring that you get the most out of your photography equipment. </p>
            <p> 3. Passionate Photography Enthusiasts: We are not just sellers; we are avid photographers ourselves. Our passion for the art of photography fuels our commitment to helping customers find the perfect tools to express their creativity and capture life's moments with precision.</p>
            <p> 4. Evolving Industry Understanding: In the dynamic world of photography, staying ahead is crucial. Our team is adept at keeping abreast of the latest trends, innovations, and industry developments, ensuring that our customers have access to the most cutting-edge and relevant products.</p>
            <p> 5. Personalized Customer Guidance: Recognizing that every photographer's journey is unique, we take pride in offering personalized guidance. Whether you're a seasoned professional or a beginner, our team is here to assist you in making informed decisions that align with your specific needs and aspirations.</p>
            <p> 6. Commitment to Exceptional Service: At CAM30, providing excellent customer service is non-negotiable. We are dedicated to creating a positive and seamless shopping experience, from the moment you explore our website to the delivery of your carefully chosen photography gear.</p>
            <p> <b>Our Mission: </b> Our mission at CAM30 is to inspire and enable creativity through innovative photography solutions. We strive to be more than just a retailer; we aim to cultivate a community where individuals can explore their artistic potential, learn, and grow. By curating a selection of top-tier cameras and accessories, coupled with exceptional customer service, we aspire to be the go-to platform that fosters a love for photography among enthusiasts and professionals alike. At CAM30, we believe that every click of the shutter should be an expression of art, and our mission is to provide the tools that turn this vision into reality.</p>
        
            <button onClick={() => { /* Handle click event to navigate to ProductPage */ }}>
                Shop Now
            </button>

            <h2>Customer Reviews</h2>

            {randomReviews.map((review, index) => (
                <div key={index}>
                    <h3>{review.customerName}</h3>
                    <p>{review.reviewContent}</p>
                    <div>
                        {/* Display the rating stars */}
                        {Array.from({ length: review.stars }, (_, i) => (
                            <span key={i}>⭐️</span>
                        ))}
                    </div>
                </div>
            ))}
        </div>
    );
};

export default HomeMainSection;
