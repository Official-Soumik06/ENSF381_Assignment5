import React from 'react';
import Header from './Header'; 
import Footer from './Footer'; 

const Login = () => {
  return (
    <div>
      <Header />
      <h1>Login Page</h1>
      <Footer />
    </div>
  );
};

export default Login;